package foro.alura.api.direccion;


    public record DatosDireccion(String calle, String distrito, String ciudad, String numero, String complemento) {
        public DatosDireccion(String calle, String distrito, String ciudad, String numero, String complemento) {
            this.calle = calle;
            this.distrito = distrito;
            this.ciudad = ciudad;
            this.numero = numero;
            this.complemento = complemento;
        }

        public String calle() {
            return this.calle;
        }

        public String distrito() {
            return this.distrito;
        }

        public String ciudad() {
            return this.ciudad;
        }

        public String numero() {
            return this.numero;
        }

        public String complemento() {
            return this.complemento;
        }
    }





