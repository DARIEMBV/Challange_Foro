package foro.alura.api;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/foro")
public class DatosRegistroForo {

    @PostMapping("/topics")
    public void registrarTopico(@RequestBody DatosRegistroForo datosRegistroForo) {
        System.out.println(datosRegistroForo);
    }

    @GetMapping("/topics")
    public String listarTopicos() {
        return "Lista de tópicos";
    }
}
